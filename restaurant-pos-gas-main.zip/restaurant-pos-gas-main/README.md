# restaurant-pos-gas
Basic Point of Sale that reads and writes to Google Sheets using Google Apps Script. 

Video of the creation of this app is here: https://youtu.be/ccVBKUUJUYI

This is a BASIC POS, it does not include any tests or data validation so it's not ready for production. I created this app to demonstrate some of the functionality in POS systems and also to learn some aspects of HTML, CSS and Javascript.

If this code helped you to learn some concepts you can buy me a coffee. Thanks!

https://www.paypal.com/paypalme/codingwithmike

Here is a link to copy a completed sheet with app:
https://bit.ly/3z81iOK
